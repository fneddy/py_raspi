#!/usr/bin/env python

# lade die LED Funktion aus der gpiozero bibliothek
from gpiozero import Buzzer
# lade die sleep Funktion aus der time bibliothek
from time import sleep

# lese https://gpiozero.readthedocs.io/en/stable/api_output.html#buzzer

# erstelle ein object buzzer
buzzer = Buzzer("GPIO4")

# wiederhole den folgenden Block 
while True:
    buzzer.on()
    sleep(0.001)
    buzzer.off()
    sleep(0.001)
     



