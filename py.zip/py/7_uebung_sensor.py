#!/usr/bin/env python
from time import sleep
import math

from ADCDevice import *
from LCD1602 import CharLCD1602

# Erstelle ein display object
display = CharLCD1602()

# initiallisiere das Display
display.init_lcd()
display.clear()

# initiallisiere sensor messung
adc = ADS7830(0x48)

# lese den sensor aus
def readSensor():
    value = adc.analogRead(0)        # read ADC value A0 pin
    voltage = value / 255.0 * 3.3        # calculate voltage
    Rt = 10 * voltage / (3.3 - voltage)    # calculate resistance value of thermistor
    tempK = 1/(1/(273.15 + 25) + math.log(Rt/10)/3950.0) # calculate temperature (Kelvin)
    tempC = tempK -273.15        # calculate temperature (Celsius)
    return tempC


text=''
while True:
    # lese den sensor und speichere in temp
    temp = readSensor()
    
    # Aufgabe:
    # wenn temperatur kleiner 26 dann schreibe normal auf display
    # wenn temperatur zwischen 26 und 29 dann schreibe attention auf display
    # wenn temperatur über 29 dann schreibe failure auf display
    
    # sende text an das display
    display.write(0,0,text)
    sleep(1)


