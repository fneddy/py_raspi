#!/usr/bin/env python

# lade die LED Funktion aus der gpiozero bibliothek
from gpiozero import Buzzer
# lade die sleep Funktion aus der time bibliothek
from time import sleep

# lese https://gpiozero.readthedocs.io/en/stable/api_output.html#buzzer

# erstelle ein object buzzer
buzzer = 

# wiederhole den folgenden Block 
while True:
    # schalte den buzzer sehr schnell an und aus
    # 0.001 s wartezeit
     



