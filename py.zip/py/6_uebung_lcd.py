#!/usr/bin/env python

# Lade die funktionalität CharLCD1602
from LCD1602 import CharLCD1602
from time import sleep

# Erstelle ein display object
display = CharLCD1602()

# initiallisiere das Display
display.init_lcd()
display.clear()


text="Hello World"
while True: 
    # schreibe einen Text an Position 0,0
    display.write(0,0,text)
    sleep(1)
    
# Aufgabe:
# ändere die ober while schleife sodass der text von links nach rechts scrollt.
