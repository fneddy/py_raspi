#!/usr/bin/env python

# lade die LED Funktion aus der gpiozero bibliothek
from gpiozero import LED
# lade die sleep Funktion aus der time bibliothek
from time import sleep


# erstelle ein object namens `led`
# benutze dafür die vorgefertigte Funktion LED
led = LED("GPIO17")

# wiederhole den folgenden Block 
while True:
    led.on()
    sleep(1)
    led.off()
    sleep(1)


