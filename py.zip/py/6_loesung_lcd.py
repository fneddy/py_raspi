#!/usr/bin/env python

# Lade die funktionalität CharLCD1602
from LCD1602 import CharLCD1602
from time import sleep

# Erstelle ein display object
display = CharLCD1602()

# initiallisiere das Display
display.init_lcd()
display.clear()

text="Hello World     "
while True:
    # wandle den text in eine liste von buchstaben um
    lst_text = list(text)
    
    # entferne das letze element aus der liste und speiche es in last
    last = lst_text.pop()
    
    # füge das element last an position 0 (anfang) in der liste hinzu
    lst_text.insert(0,last)
    
    # wandle die buchstabenliste wieder in einen text um
    
    text = ''.join(lst_text)
    
    # schreibe den Text an Position 0,0
    display.write(0,0,text)
    sleep(1)
    

