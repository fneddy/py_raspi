#!/usr/bin/env python

# lade die LED Funktion aus der gpiozero bibliothek
from gpiozero import Buzzer,LED,Button
# lade die sleep Funktion aus der time bibliothek
from time import sleep

# lese https://gpiozero.readthedocs.io/en/stable/api_output.html#buzzer
# https://gpiozero.readthedocs.io/en/stable/api_input.html#button

# erstelle ein object buzzer
button = Button("GPIO20")
led = LED("GPIO17")

# wiederhole den folgenden Block 
while True:
    # 1. warte das Taste gedrückt wird
    button.wait_for_press()
    # 2. schalte led an
    led.on()
    # 3. warte 1s
    sleep(1)
    # 4. schalte led aus
    led.off()
     




