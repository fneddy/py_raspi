#!/usr/bin/env python

# lade die LED Funktion aus der gpiozero bibliothek
from gpiozero import Buzzer,LED,Button
# lade die sleep Funktion aus der time bibliothek
from time import sleep

# lese https://gpiozero.readthedocs.io/en/stable/api_output.html#buzzer
# https://gpiozero.readthedocs.io/en/stable/api_input.html#button

# erstelle ein object buzzer
button = 
led =

# wiederhole den folgenden Block 
while True:
    # 1. warte das Taste gedrückt wird
    # 2. schalte led an
    # 3. warte 1s
    # 4. schalte led aus
     




